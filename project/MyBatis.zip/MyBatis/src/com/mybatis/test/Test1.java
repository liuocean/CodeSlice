package com.mybatis.test;

import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;
import com.mybatis.models.User;
import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;

public class Test1 {

    public static void main(String[] args) throws IOException {
        //mybatis�������ļ�
        String resource = "com/mybatis/config/config.xml";
        //ʹ��MyBatis�ṩ��Resources�����mybatis�������ļ�
        Reader reader = Resources.getResourceAsReader(resource); 
        //����sqlSession�Ĺ���
        SqlSessionFactory sessionFactory = new SqlSessionFactoryBuilder().build(reader);
        //������ִ��ӳ���ļ���sql��sqlSession
        SqlSession session = sessionFactory.openSession();
        /**
         * getUser��select��ǩ��id����ֵ��ͨ��select��ǩ��id����ֵ�Ϳ����ҵ�Ҫִ�е�SQL
         */
        String statement = "com.mybatis.mappers.UserMapper.getUser";
        try {
        	User user = session.selectOne(statement, 1); //��ѯidΪ1��User
        	System.out.println(user);
        }
        finally {
            session.close();
        }       
    }
}	
	
//	private static SqlSessionFactory sqlSessionFactory;
//	private static Reader reader;
//
//	static {
//		try {
//			String resource = "com/mybatis/config/config.xml";
//			reader = Resources.getResourceAsReader(resource);
//			sqlSessionFactory = new SqlSessionFactoryBuilder().build(reader);
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//	}
//	
//	public static void main(String[] args) {
//		// TODO Auto-generated method stub
//		SqlSession session = sqlSessionFactory.openSession();
//		
//		try {
//			String statement = "com.mybatis.mappers.UserMapper.getUser";//ӳ��sql�ı�ʶ�ַ���
//			User user = (User) session.selectOne(statement, 1);
//			if(user!=null){
//				System.out.println(user);
//			}
//		} finally {
//			session.close();
//		}
//	}
      
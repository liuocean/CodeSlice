package com.mybatis.mappers;
import com.mybatis.models.User;

public interface UserMapper {
	public User getUser(int id);
}
